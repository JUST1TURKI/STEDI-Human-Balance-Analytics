import mysql.connector

# Connect to the MySQL server
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="customers"
)

# Create a cursor object to execute SQL queries
cursor = connection.cursor()

# SQL statement to create the external table
create_table_query = '''
CREATE TABLE IF NOT EXISTS customer_landing (
  serialnumber VARCHAR(255),
  sharewithpublicasofdate BIGINT,
  birthday VARCHAR(255),
  registrationdate BIGINT,
  sharewithresearchasofdate BIGINT,
  customername VARCHAR(255),
  email VARCHAR(255),
  lastupdatedate BIGINT,
  phone VARCHAR(255),
  sharewithfriendsasofdate BIGINT
);
'''

# Execute the SQL statement
cursor.execute(create_table_query)

# Commit the changes
connection.commit()

# Close the cursor and connection
cursor.close()
connection.close()
