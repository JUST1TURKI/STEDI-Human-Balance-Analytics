import mysql.connector

# Connect to the MySQL server
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="accelerometer"
)

# Create a cursor object to execute SQL queries
cursor = connection.cursor()

# Execute SQL statement to create the table
try:
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS `stedi-project`.`accelerometer_landing` (
            `user` VARCHAR(255),
            `timeStamp` BIGINT,
            `x` FLOAT,
            `y` FLOAT,
            `z` FLOAT
        )
    ''')

    # Commit the changes
    connection.commit()

except Exception as e:
    print(f"Error: {e}")
    # Rollback in case of an error
    connection.rollback()

finally:
    # Close the cursor and connection
    cursor.close()
    connection.close()
